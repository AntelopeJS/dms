import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
} from "node:crypto";
import { isBoolean, isNumber, isRecord, isString } from "../type-guards.mjs";

export const SESSION_COOKIE = "dms_session";
const REQUEST_SESSION = Symbol("dms-request-session");
/** @type {WeakSet<import("node:http").ServerResponse>} */
const CLEARED = new WeakSet();
const MAX_AGE = 60 * 60 * 24 * 30;
/** How far ahead of this instance's clock another instance may stamp a session. */
const CLOCK_SKEW_MS = 5 * 60 * 1000;

/**
 * The session a module writes: the `DmsSession` of `#dms/server`.
 *
 * @typedef {import("../../server-module.ts").DmsSession} Session
 */

/**
 * A request, and the session `setRequestSession` set on it for the rest of the
 * request.
 *
 * @typedef {import("node:http").IncomingMessage & {
 *   [REQUEST_SESSION]?: Session | undefined
 * }} SessionRequest
 */

/**
 * A suffix that keeps this instance's cookies apart from another's on the same
 * host. Browsers scope cookies by hostname, not port: without it, two DMS
 * frontends on localhost:3000 and localhost:3001 would overwrite each other's
 * session, each failing to decrypt the other's and signing the user out. The
 * suffix follows the backend, so a restart keeps the cookies it wrote.
 *
 * A `DMS_API_BASE_URL` that is not a URL is hashed as written: the raw string
 * still tells two backends apart.
 */
function cookieScope() {
  const backendUrl = (process.env.DMS_API_BASE_URL ?? "").trim();
  let canonical = backendUrl;
  try {
    const url = new URL(backendUrl);
    if (url.hostname === "localhost" || url.hostname === "[::1]")
      url.hostname = "127.0.0.1";
    canonical = url.toString().replace(/\/$/, "");
  } catch {}
  return createHash("sha256").update(canonical).digest("hex").slice(0, 12);
}

/**
 * The name `name` takes in this instance's cookie jar.
 *
 * @param {string} name
 */
export function scopedCookieName(name) {
  return `${name}_${cookieScope()}`;
}

function key() {
  const secret = process.env.DMS_SESSION_SECRET;
  if (!secret || secret.length < 32)
    throw new Error(
      "DMS_SESSION_SECRET must contain at least 32 characters; " +
        "generate one with: openssl rand -hex 32",
    );
  return createHash("sha256").update(secret).digest();
}

/**
 * Seals `value` for the cookie `name` alone: the name is the AES-GCM
 * additional authenticated data, so the value opens under no other cookie.
 *
 * @param {string} name The cookie's name in the jar
 * @param {unknown} value A session, or the value of a module's sealed cookie
 * @returns {string}
 */
function encode(name, value) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key(), iv);
  cipher.setAAD(Buffer.from(name));
  const encrypted = Buffer.concat([
    cipher.update(JSON.stringify(value)),
    cipher.final(),
  ]);
  return Buffer.concat([iv, cipher.getAuthTag(), encrypted]).toString(
    "base64url",
  );
}

/**
 * @param {string} name The cookie's name in the jar
 * @param {string} value The cookie's value
 * @returns {unknown} What was sealed for `name`, as the JSON it was written
 *   from, `undefined` when it does not open
 */
function decode(name, value) {
  try {
    const payload = Buffer.from(value, "base64url");
    const decipher = createDecipheriv(
      "aes-256-gcm",
      key(),
      payload.subarray(0, 12),
      { authTagLength: 16 },
    );
    decipher.setAuthTag(payload.subarray(12, 28));
    decipher.setAAD(Buffer.from(name));
    return JSON.parse(
      Buffer.concat([
        decipher.update(payload.subarray(28)),
        decipher.final(),
      ]).toString(),
    );
  } catch {
    return undefined;
  }
}

/**
 * @param {unknown} value
 * @returns {value is Session & { updatedAt: number }} Whether `value` is what
 *   `writeSession` seals
 */
function isSession(value) {
  if (
    !isRecord(value) ||
    !isBoolean(value.persistent) ||
    !isNumber(value.updatedAt)
  )
    return false;
  const { user } = value;
  return (
    ["accessToken", "refreshToken", "accountId", "activeTenantId"].every(
      (field) => !Object.hasOwn(value, field) || isString(value[field]),
    ) &&
    (!Object.hasOwn(value, "user") ||
      (isRecord(user) &&
        (!Object.hasOwn(user, "language") || isString(user.language))))
  );
}

/**
 * Cookie attributes. Without a `maxAge` the cookie lasts as long as the
 * browser session: it is gone once the browser is closed.
 *
 * @param {number | undefined} maxAge
 * @param {string} [path]
 */
function attributes(maxAge, path = "/") {
  const secure = process.env.DMS_COOKIE_SECURE !== "false" ? "; Secure" : "";
  const lifetime = maxAge === undefined ? "" : `; Max-Age=${maxAge}`;
  return `Path=${path}; HttpOnly; SameSite=Lax${lifetime}${secure}`;
}

/**
 * A session outlives the browser only when it is written `persistent: true`.
 *
 * @param {Session} session
 */
function lifetime(session) {
  return session.persistent === true ? MAX_AGE : undefined;
}

/**
 * The cookie a `Set-Cookie` line sets: its name and path, which a browser
 * keeps one value for.
 *
 * @param {string} line
 */
function cookieIdentity(line) {
  const path = /;\s*Path=([^;]*)/i.exec(line)?.[1] ?? "/";
  return `${line.slice(0, line.indexOf("="))}\n${path}`;
}

/**
 * Adds a `Set-Cookie` line, in place of any line the response already holds
 * for the same cookie: the last write of a cookie in a request is the one the
 * browser keeps, whatever order it reads the lines in.
 *
 * @param {import("node:http").ServerResponse} response
 * @param {string} name
 * @param {string} value
 * @param {string} cookieAttributes
 */
function appendCookie(response, name, value, cookieAttributes) {
  const cookie = `${scopedCookieName(name)}=${value}; ${cookieAttributes}`;
  const identity = cookieIdentity(cookie);
  const current = [response.getHeader("set-cookie") ?? []]
    .flat()
    .map(String)
    .filter((line) => cookieIdentity(line) !== identity);
  response.setHeader(
    "set-cookie",
    current.length ? [cookie, ...current] : cookie,
  );
}

/**
 * @param {import("node:http").ServerResponse} response
 * @param {string} name
 * @param {unknown} value
 * @param {string} cookieAttributes
 */
function appendSealedCookie(response, name, value, cookieAttributes) {
  appendCookie(
    response,
    name,
    encode(scopedCookieName(name), value),
    cookieAttributes,
  );
}

/**
 * @param {SessionRequest} request
 * @returns {Session | undefined} The session set for the request, else the one
 *   the cookie seals, `undefined` when there is none
 */
export function readSession(request) {
  if (REQUEST_SESSION in request) return request[REQUEST_SESSION];
  const sealed = readSealedCookie(request, SESSION_COOKIE);
  if (!isSession(sealed)) return undefined;
  const age = Date.now() - sealed.updatedAt;
  return age <= MAX_AGE * 1000 && age >= -CLOCK_SKEW_MS ? sealed : undefined;
}

/**
 * @param {SessionRequest} request
 * @param {Session | undefined} session
 */
export function setRequestSession(request, session) {
  request[REQUEST_SESSION] = session;
}

/**
 * Seals `session` into the session cookie, stamped with `updatedAt`. It opens
 * for 30 days from that stamp, whatever the browser keeps.
 *
 * @param {import("node:http").ServerResponse} response
 * @param {Session} session
 */
export function writeSession(response, session) {
  if (!isBoolean(session.persistent))
    throw new TypeError(
      "A session needs persistent: true to outlive the browser, or false to end with it",
    );
  session.updatedAt = Date.now();
  appendSealedCookie(
    response,
    SESSION_COOKIE,
    session,
    attributes(lifetime(session)),
  );
}

/** @param {import("node:http").ServerResponse} response */
export function clearSession(response) {
  CLEARED.add(response);
  appendCookie(response, SESSION_COOKIE, "", attributes(0));
}

/**
 * Whether `clearSession` cleared the session on `response`.
 *
 * @param {import("node:http").ServerResponse} response
 */
export function clearedSession(response) {
  return CLEARED.has(response);
}

/**
 * @param {import("node:http").IncomingMessage} request
 * @param {string} name
 * @returns {unknown} What was sealed, as the JSON it was written from,
 *   `undefined` when there is none or it does not open
 */
export function readSealedCookie(request, name) {
  const scoped = scopedCookieName(name);
  const cookies = request.headers.cookie?.split(";") ?? [];
  const value = cookies
    .map((part) => part.trim().split("="))
    .find(([key]) => key === scoped)?.[1];
  return value ? decode(scoped, value) : undefined;
}

/**
 * @param {import("node:http").ServerResponse} response
 * @param {string} name
 * @param {unknown} value
 * @param {number | undefined} maxAge
 * @param {string} [path]
 */
export function writeSealedCookie(response, name, value, maxAge, path = "/") {
  appendSealedCookie(response, name, value, attributes(maxAge, path));
}

/**
 * @param {import("node:http").ServerResponse} response
 * @param {string} name
 * @param {string} [path]
 */
export function clearSealedCookie(response, name, path = "/") {
  appendCookie(response, name, "", attributes(0, path));
}
